﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication6A.Models;
using System.Web.Security;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace WebApplication6A.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult About()
        {
            return View();
        }
        
        public ActionResult Contact()
        {
            return View();
        }
        
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]

        public ActionResult Login(UserModel model, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string sqlQuery = "SELECT COUNT(1) FROM Users WHERE Username=@Username AND Password=@Password";
                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    cmd.Parameters.AddWithValue("@Username", model.Username);
                    cmd.Parameters.AddWithValue("@Password", model.Password);
                    con.Open();
                    int userCount = (int)cmd.ExecuteScalar();
                    if (userCount == 1)
                    {

                        FormsAuthentication.SetAuthCookie(model.Username, false);
                        if (Url.IsLocalUrl(returnUrl) && returnUrl.Length > 1)
                        {
                            return Redirect(returnUrl);
                        }
                        else
                        {
                            return RedirectToAction("Index");
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", "Invalid username or password.");
                    }
                }
            }

            return View(model);
        }
        public ActionResult Signout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login");
        }

        [Authorize]
        public ActionResult Courses()
        {
            return View();
        }
        [Authorize]
        public ActionResult AddCourses()
        {
            return View();
        }

        [Authorize]
        [HttpPost]
        public ActionResult AddCourses(CoursesModel cm)
        {
            if (ModelState.IsValid)
            {
                string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string cmdText = "INSERT INTO Courses (CourseId, CourseName, CourseInstructor) VALUES (@CourseId, @CourseName, @CourseInstructor)";
                    using (SqlCommand cmd = new SqlCommand(cmdText, con))
                    {
                        cmd.Parameters.AddWithValue("@CourseId", cm.CourseId);
                        cmd.Parameters.AddWithValue("@CourseName", cm.CourseName);
                        cmd.Parameters.AddWithValue("@CourseInstructor", cm.CourseInstructor);

                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
                return RedirectToAction("Index");
            }
            return View(cm);
        }
        [Authorize]
        public ActionResult ViewCourses()
        {
            List<CoursesModel> courses = new List<CoursesModel>();
            string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
            string query = "SELECT CourseId, CourseName, CourseInstructor FROM Courses;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    CoursesModel course = new CoursesModel();
                    course.CourseId = Convert.ToInt32(dr["CourseId"]);
                    course.CourseName = dr["CourseName"].ToString();
                    course.CourseInstructor = dr["CourseInstructor"].ToString();

                    courses.Add(course);
                }
                conn.Close();
            }

            return View(courses);
        }

        [Authorize]
        public ActionResult Students()
        {
            return View();
        }
        [Authorize]
        [HttpGet]
        public ActionResult AddStudents()
        {
            return View();
        }
        [Authorize]
        [HttpPost]
        public ActionResult AddStudents(StudentsModel sm)
        {
            if (ModelState.IsValid)
            {
                string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string cmdText = "INSERT INTO Students (SID,Name, Email, DateOfBirth, Address) VALUES (@SID,@Name, @Email, @DateOfBirth, @Address)";
                    using (SqlCommand cmd = new SqlCommand(cmdText, con))
                    {
                        cmd.Parameters.AddWithValue("@SID", sm.SID);
                        cmd.Parameters.AddWithValue("@Name", sm.Name);
                        cmd.Parameters.AddWithValue("@Email", sm.Email);
                        cmd.Parameters.AddWithValue("@DateOfBirth", sm.DateOfBirth);
                        cmd.Parameters.AddWithValue("@Address", sm.Address);

                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
                return RedirectToAction("Index");
            }
            return View(sm);
        }
        [Authorize]
        public ActionResult ViewStudents()
        {
            List<StudentsModel> students = new List<StudentsModel>();
            string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
            string query = "SELECT SID, Name, Email, DateOfBirth, Address FROM Students;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    StudentsModel student = new StudentsModel();
                    student.SID = Convert.ToInt32(dr["SID"]);
                    student.Name = dr["Name"].ToString();
                    student.Email = dr["Email"].ToString();
                    student.DateOfBirth = dr["DateOfBirth"].ToString();  
                    student.Address = dr["Address"].ToString();

                    students.Add(student);
                }
                conn.Close();
            }
            return View(students);
        }
        public ActionResult DeleteCourse(int id)
        {
            string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Courses WHERE CourseID = @CourseID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@CourseID", id);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            return RedirectToAction("ViewCourses"); 
        }

        public ActionResult DeleteStudent(int id)
        {
            string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Students WHERE SID = @SID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@SID", id);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            return RedirectToAction("ViewStudents"); 
        }
        [HttpGet]
        public ActionResult EditStudent(int id)
        {
            StudentsModel student = null;
            string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string sqlQuery = "SELECT * FROM Students WHERE SID = @SID";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.Parameters.AddWithValue("@SID", id);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    student = new StudentsModel()
                    {
                        SID = Convert.ToInt32(dr["SID"]),
                        Name = dr["Name"].ToString(),
                        Email = dr["Email"].ToString(),
                        DateOfBirth = dr["DateOfBirth"].ToString(),
                        Address = dr["Address"].ToString()
                    };
                }
                dr.Close();
            }
            if (student == null)
            {
                return HttpNotFound();
            }
            return View(student);
        }
      
        [HttpPost]
        public ActionResult EditStudent(StudentsModel model)
        {
            if (ModelState.IsValid)
            {
                string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string cmdText = "UPDATE Students SET Name=@Name, Email=@Email, DateOfBirth=@DateOfBirth, Address=@Address WHERE SID=@SID";
                    SqlCommand cmd = new SqlCommand(cmdText, con);
                    cmd.Parameters.AddWithValue("@SID", model.SID);
                    cmd.Parameters.AddWithValue("@Name", model.Name);
                    cmd.Parameters.AddWithValue("@Email", model.Email);
                    cmd.Parameters.AddWithValue("@DateOfBirth", model.DateOfBirth);
                    cmd.Parameters.AddWithValue("@Address", model.Address);
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
                return RedirectToAction("ViewStudents");
            }
            return View(model);
        }
        [HttpGet]
        public ActionResult EditCourse(int id)
        {
            CoursesModel course = null;
            string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string sqlQuery = "SELECT * FROM Courses WHERE CourseId = @CourseId";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.Parameters.AddWithValue("@CourseId", id);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    course = new CoursesModel()
                    {
                        CourseId = Convert.ToInt32(dr["CourseId"]),
                        CourseName = dr["CourseName"].ToString(),
                        CourseInstructor = dr["CourseInstructor"].ToString()
                    };
                }
                dr.Close();
            }
            if (course == null)
            {
                return HttpNotFound();
            }
            return View(course);
        }
        [HttpPost]
        public ActionResult EditCourse(CoursesModel model)
        {
            if (ModelState.IsValid)
            {
                string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string cmdText = "UPDATE Courses SET CourseName=@CourseName, CourseInstructor=@CourseInstructor WHERE CourseId=@CourseId";
                    SqlCommand cmd = new SqlCommand(cmdText, con);
                    cmd.Parameters.AddWithValue("@CourseId", model.CourseId);
                    cmd.Parameters.AddWithValue("@CourseName", model.CourseName);
                    cmd.Parameters.AddWithValue("@CourseInstructor", model.CourseInstructor);
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
                return RedirectToAction("ViewCourses"); 
            }
            return View(model);
        }
        [Authorize]
        public ActionResult Registerations()
        {
            return View();
        }
        [Authorize]
        [HttpGet]
        public ActionResult AddRegistrations()
        {
            var viewModel = new RegisterationModel(); 
            viewModel.Students = GetStudents();
            viewModel.Courses = GetCourses();
            return View(viewModel);
        }
        [Authorize]
        [HttpPost]
        public ActionResult AddRegistrations(RegisterationModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    AddRegistrationToDatabase(model);
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "Error: " + ex.Message);
                }
            }

            model.Students = GetStudents();
            model.Courses = GetCourses();
            return View(model);
        }
        private void AddRegistrationToDatabase(RegisterationModel model)
        {
            string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string cmdText = "INSERT INTO Registrations (SID, CourseId) VALUES (@SID, @CourseId)";
                using (SqlCommand cmd = new SqlCommand(cmdText, con))
                {
                    cmd.Parameters.AddWithValue("@SID", model.SID);
                    cmd.Parameters.AddWithValue("@CourseId", model.CourseId);
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }
        private List<SelectListItem> GetStudents()
        {
            List<SelectListItem> students = new List<SelectListItem>();
            string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT SID, Name FROM Students", con);
                con.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        students.Add(new SelectListItem { Text = reader["Name"].ToString(), Value = reader["SID"].ToString() });
                    }
                }
            }
            return students;
        }

        private List<SelectListItem> GetCourses()
        {
            List<SelectListItem> courses = new List<SelectListItem>();
            string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT CourseId, CourseName FROM Courses", con);
                con.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        courses.Add(new SelectListItem { Text = reader["CourseName"].ToString(), Value = reader["CourseId"].ToString() });
                    }
                }
            }
            return courses;
        }
        [Authorize]
        public ActionResult ViewRegistrations()
        {
            List<RegisterationModel> registrations = new List<RegisterationModel>();
            string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
            string query = "SELECT RegistrationId, SID, CourseId FROM Registrations;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        RegisterationModel registration = new RegisterationModel
                        {
                            RegistrationId = Convert.ToInt32(dr["RegistrationId"]),
                            SID = Convert.ToInt32(dr["SID"]),
                            CourseId = Convert.ToInt32(dr["CourseId"]),
                        };
                        registrations.Add(registration);
                    }
                }
                conn.Close();
            }
            return View(registrations);
        }
        [Authorize]
        public ActionResult DeleteRegistration(int id)
        {
            string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Registrations WHERE RegistrationId = @RegistrationId";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@RegistrationId", id);
                conn.Open();
                cmd.ExecuteNonQuery(); 
                conn.Close();
            }
            return RedirectToAction("ViewRegistrations");
        }
        [HttpGet]
        public ActionResult EditRegistration(int id)
        {
            RegisterationModel registration = null;
            string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string sqlQuery = "SELECT * FROM Registrations WHERE RegistrationId = @RegistrationId";
                SqlCommand cmd = new SqlCommand(sqlQuery, conn);
                cmd.Parameters.AddWithValue("@RegistrationId", id);
                conn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        registration = new RegisterationModel
                        {
                            RegistrationId = Convert.ToInt32(dr["RegistrationId"]),
                            SID = Convert.ToInt32(dr["SID"]),
                            CourseId = Convert.ToInt32(dr["CourseId"])
                        };
                    }
                }
            }
            if (registration == null)
            {
                return HttpNotFound();
            }

            registration.Students = FetchStudentsForDropdown();
            registration.Courses = FetchCoursesForDropdown();

            return View(registration);
        }

        private IEnumerable<SelectListItem> FetchStudentsForDropdown()
        {
            List<SelectListItem> students = new List<SelectListItem>();
            string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS; Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT SID FROM Students", conn);
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        students.Add(new SelectListItem
                        {
                            Value = dr["SID"].ToString(),
                            Text = dr["SID"].ToString()  
                        });
                    }
                }
            }
            return students;
        }

        private IEnumerable<SelectListItem> FetchCoursesForDropdown()
        {
            List<SelectListItem> courses = new List<SelectListItem>();
            string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS; Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT CourseId FROM Courses", conn);
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        courses.Add(new SelectListItem
                        {
                            Value = dr["CourseId"].ToString(),
                            Text = dr["CourseId"].ToString()  
                        });
                    }
                }
            }
            return courses;
        }


        [HttpPost]

        public ActionResult EditRegistration(RegisterationModel model)
        {
            if (ModelState.IsValid)
            {
                string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string updateQuery = "UPDATE Registrations SET SID = @SID, CourseId = @CourseId WHERE RegistrationId = @RegistrationId";
                    SqlCommand cmd = new SqlCommand(updateQuery, conn);
                    cmd.Parameters.AddWithValue("@RegistrationId", model.RegistrationId);
                    cmd.Parameters.AddWithValue("@SID", model.SID);
                    cmd.Parameters.AddWithValue("@CourseId", model.CourseId);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                return RedirectToAction("ViewRegistrations");
            }
            return View(model);
        }
        
        [Authorize]
        public ActionResult TotalStudents()
        {
            int totalStudents = 0;
            string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string sqlQuery = "SELECT COUNT(*) FROM Students";
                SqlCommand cmd = new SqlCommand(sqlQuery, conn);
                conn.Open();
                totalStudents = (int)cmd.ExecuteScalar();
            }
            ViewBag.TotalStudents = totalStudents;
            return View();
        }
        [Authorize]
        public ActionResult TotalCourses()
        {
            int totalCourses = 0;
            string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string sqlQuery = "SELECT COUNT(*) FROM Courses";  
                SqlCommand cmd = new SqlCommand(sqlQuery, conn);
                conn.Open();
                totalCourses = (int)cmd.ExecuteScalar(); 
            }
            ViewBag.TotalCourses = totalCourses;  
            return View();  
        }
        [Authorize]
        public ActionResult TotalRegistrations()
        {
            int totalRegistrations = 0;
            string connectionString = "Data Source=DESKTOP-K34FMJP\\SQLEXPRESS;Initial Catalog=DBMSLABASSIGNMENT01;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string sqlQuery = "SELECT COUNT(*) FROM Registrations";
                SqlCommand cmd = new SqlCommand(sqlQuery, conn);
                conn.Open();
                totalRegistrations = (int)cmd.ExecuteScalar();  
            }
            ViewBag.TotalRegistrations = totalRegistrations;  
            return View();  
        }


































    }
}