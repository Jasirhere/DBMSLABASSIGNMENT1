﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Linq;
using System.Web;

namespace WebApplication6A.Models
{
    public class RegisterationModel
    {
        public int SID { get; set; }
        public int CourseId { get; set; }
        public IEnumerable<SelectListItem> Students { get; set; }
        public IEnumerable<SelectListItem> Courses { get; set; }
        public int RegistrationId { get; set; }  


    }
}