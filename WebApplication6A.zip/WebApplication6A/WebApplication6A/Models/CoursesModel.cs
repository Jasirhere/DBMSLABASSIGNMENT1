﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication6A.Models
{
    public class CoursesModel
    {
        public int CourseId { get; set; }

        public string CourseName { get; set; }

        public string CourseInstructor { get; set; }

    }
}