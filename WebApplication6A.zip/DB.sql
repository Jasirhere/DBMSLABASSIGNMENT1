Create Database DBMSLABASSIGNMENT01

use DBMSLABASSIGNMENT01

CREATE TABLE Users (
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    Username VARCHAR(50) NOT NULL,
    Password VARCHAR(50) NOT NULL
);

CREATE TABLE Courses (
    CourseId INT PRIMARY KEY , 
    CourseName varchar(50) , 
    CourseInstructor varchar(50),
);

CREATE TABLE Students (
    SID INT PRIMARY KEY,              
    Name VARCHAR(50),                
    Email VARCHAR(60),               
    DateOfBirth VARCHAR(40),                
    Address VARCHAR(255)              
);

CREATE TABLE Registrations (
    RegistrationId INT PRIMARY KEY IDENTITY(1,1),
	SID INT,
    CourseId INT,
    CONSTRAINT FK_Registrations_Students FOREIGN KEY (SID) REFERENCES Students(SID),
    CONSTRAINT FK_Registrations_Courses FOREIGN KEY (CourseId) REFERENCES Courses(CourseId)
);




